#include <iostream>
using std::cout;
using std::cin;
using std::endl;

int main() {
    int *x = new int;
    *x=100;
    cout<<"la valeur de x est :"<<*x<<endl;
    cout<<"l'adresse de x est :"<<x<<endl;
    return 0;
}